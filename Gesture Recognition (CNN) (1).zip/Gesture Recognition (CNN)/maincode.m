clear all;clc
dataDir = 'C:\Users\Documents\MATLAB\GR\dataset5\A';
inputSize = [224 224 3];
readAndPreprocessImage = @(filename) readAndPreprocessImage(filename, inputSize);
gestureData = imageDatastore(dataDir, ...
    'IncludeSubfolders', true, ...
    'LabelSource', 'foldernames', ...
    'ReadFcn', readAndPreprocessImage);
inputSize = [224 224 3];

[trainingData, testData] = splitEachLabel(gestureData, 0.8, 'randomized');
numClasses = numel(categories(gestureData.Labels));
layers = [
    imageInputLayer([224 224 3])
    convolution2dLayer(3, 64, 'Padding', 'same')
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)
    convolution2dLayer(3, 128, 'Padding', 'same')
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)
    convolution2dLayer(3, 256, 'Padding', 'same')
    reluLayer
    convolution2dLayer(3, 256, 'Padding', 'same')
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)
    convolution2dLayer(3, 512, 'Padding', 'same')
    reluLayer
    convolution2dLayer(3, 512, 'Padding', 'same')
    reluLayer
    maxPooling2dLayer(2, 'Stride', 2)
    fullyConnectedLayer(4096)
    reluLayer
    dropoutLayer(0.5)
    fullyConnectedLayer(4096)
    reluLayer
    dropoutLayer(0.5)
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer];
options = trainingOptions('sgdm', ...
    'MiniBatchSize', 32, ...
    'MaxEpochs', 10, ...
    'InitialLearnRate', 1e-4, ...
    'Verbose', false, ...
    'Plots', 'training-progress');
net = trainNetwork(trainingData, layers, options);
predictedLabels = classify(net, testData);
accuracy = mean(predictedLabels == testData.Labels);
disp("Accuracy: " + accuracy*100 + "%");